import { Injectable } from '@angular/core';
import { feedbackModal } from '../model/feedbackModal';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class FeedbackService {
  feedbackArray: feedbackModal[];
  private baseUrl = 'http://localhost:8880';
  constructor(private http: HttpClient, private router: Router) {
    this.feedbackArray = [];
  }

  add(feedback: feedbackModal, id: number) {
    this.router.navigate(['/submit']);
    var body = {
      customerFirstName: feedback.customerFirstName,
      productRating: feedback.productRating,
      productComment: feedback.productComment
    };
    return this.http.post<feedbackModal>(this.baseUrl + '/addreview/' + id, body);

  }

  display(id: number) {
    id = 1001;
    return this.http.get<feedbackModal[]>(`${this.baseUrl}/getreview/${id}`);
  }
}
