import { Component, OnInit } from '@angular/core';
import { feedbackModal } from '../model/feedbackModal';
import { FeedbackService } from '../service/feedback.service';

@Component({
  selector: 'app-submit',
  templateUrl: './submit.component.html',
  styleUrls: ['./submit.component.css']
})
export class SubmitComponent implements OnInit {

  feedback: feedbackModal;
  allFeedbacks: feedbackModal[] = [];
  id: number;
  constructor(private feedbackService: FeedbackService) {
    this.feedback = new feedbackModal();
    this.allFeedbacks = [];
    // this.allFeedbacks = this.feedbackService.display();
    this.id = 1001;
  }

  ngOnInit() {
  }
  // add() {
  //   this.feedbackService.add(this.feedback, this.id);
  //   console.log(this.feedback);
  //   this.feedback = new feedbackModal();
  // }
  getAll() {
    this.feedbackService.display(this.id).subscribe(
      result => { this.allFeedbacks = result; },
      error => { console.log(error); }
    );
  }
}
