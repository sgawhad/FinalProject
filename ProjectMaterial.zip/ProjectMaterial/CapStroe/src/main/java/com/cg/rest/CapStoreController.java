package com.cg.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Review;
import com.cg.service.CapStoreService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class CapStoreController {

	@Autowired
	private CapStoreService service;

	@PostMapping(path = "/addreview/{productId}",  produces = "application/json",consumes = "application/json")
	public String createReview(@RequestBody Review review, @PathVariable("productId") int productId) {
		return service.addReview(productId, review);
	}

	@PutMapping(path = "/updatereview", consumes = "application/json")
	public String updateEmployee(@RequestBody Review review) {
		return service.updateReview(review);
	}

	@DeleteMapping(path = "/deletereview/{id}")
	public String deleteReview(@PathVariable("id") int reviewId) {
		try {
			return service.deleteReview(reviewId);
		} catch (Exception e) {
			return "No such review found for " + reviewId;
		}
	}

	@GetMapping(path = "/getreview/{productId}")
	public List<Review> getreview(@PathVariable("productId") int productId) {
		List<Review> allReviews = service.getProductReviewById(productId);
		return allReviews;
	}
}
