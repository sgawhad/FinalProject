package com.cg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "customer")
public class Customer {

	@Id
	@Column(name = "customer_id")
	@SequenceGenerator(name = "seq", initialValue = 1, allocationSize = 100)
	private int customerId;

	@Column(name = "customer_firstname", length = 20)
	private String customerFirstName;

	@Column(name = "customer_lastname", length = 20)
	private String customerLastName;

	@Column(name = "customer_email", length = 20)
	private String customerEmail;

	@Column(name = "customer_password", length = 20)
	private String customerPassword;

	@Column(name = "customer_contact", length = 10)
	private String customerContact;

	@Column(name = "is_customer_activated", length = 20)
	private String isCustomerActivated;

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerFirstName() {
		return customerFirstName;
	}

	public void setCustomerFirstName(String customerFirstName) {
		this.customerFirstName = customerFirstName;
	}

	public String getCustomerLastName() {
		return customerLastName;
	}

	public void setCustomerLastName(String customerLastName) {
		this.customerLastName = customerLastName;
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	public String getCustomerPassword() {
		return customerPassword;
	}

	public void setCustomerPassword(String customerPassword) {
		this.customerPassword = customerPassword;
	}

	public String getCustomerContact() {
		return customerContact;
	}

	public void setCustomerContact(String customerContact) {
		this.customerContact = customerContact;
	}

	public String getIsCustomerActivated() {
		return isCustomerActivated;
	}

	public void setIsCustomerActivated(String isCustomerActivated) {
		this.isCustomerActivated = isCustomerActivated;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerFirstName=" + customerFirstName + ", customerLastName="
				+ customerLastName + ", customerEmail=" + customerEmail + ", customerPassword=" + customerPassword
				+ ", customerContact=" + customerContact + ", isCustomerActivated=" + isCustomerActivated + "]";
	}

}
