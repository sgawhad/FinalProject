package com.cg.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "merchant")
public class Merchant {

	@Id
	@Column(name = "merchant_id", length = 10)
	@GeneratedValue
	private int id;

	@Column(name = "merchant_email")
	private String email;

	/************** Relationships ******************/
	@OneToMany(mappedBy = "merchant", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	private List<Inventory> Inventory = new ArrayList<Inventory>();
}
