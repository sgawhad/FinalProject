package com.cg.service;

import java.util.List;

import com.cg.bean.Product;
import com.cg.bean.Review;

public interface CapStoreService {

	String addReview(int productId, Review review);

	String updateReview(Review review);

	String deleteReview(int reviewId);

	List<Review> getProductReviewById(int productId);

	Product getProductByid(int productId);

	Review getReview(int reviewId);

}
