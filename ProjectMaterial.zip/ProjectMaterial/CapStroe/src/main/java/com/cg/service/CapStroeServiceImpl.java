package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.bean.Product;
import com.cg.bean.Review;
import com.cg.repo.ProductRepo;
import com.cg.repo.ReviewRepo;

@Repository
@Transactional
public class CapStroeServiceImpl implements CapStoreService {

	@Autowired
	private ReviewRepo reviewRepo;

	@Autowired
	ProductRepo productRepo;

	@Override
	public String addReview(int productId, Review review) {
		Product product = productRepo.findById(productId).get();
		product.addReview(review);
		productRepo.save(product);
		return "Review added";
	}

	@Override
	public String updateReview(Review review) {
		reviewRepo.save(review);
		return "Review Updated";
	}

	@Override
	public String deleteReview(int reviewId) {
		reviewRepo.deleteById(reviewId);
		return "Review deleted ";
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public List<Review> getProductReviewById(int productId) {
		Product product = productRepo.findById(productId).get();
		// Review review = new Review();
		// review.setProductId(productId);
		List<Review> l = product.getReview();
		System.out.println(l);
		return l;

	}

	@Override
	public Product getProductByid(int productId) {
		return productRepo.findById(productId).get();

	}

	@Override
	public Review getReview(int reviewId) {
		return reviewRepo.findById(reviewId).get();
	}

}
