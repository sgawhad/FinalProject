package com.cg.test;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.bean.Product;
import com.cg.service.CapStoreService;
import com.cg.service.CapStroeServiceImpl;

public class ReviewTest {

	private CapStoreService service;

	@Before
	public void init() {
		service = new CapStroeServiceImpl();
	}

	@After
	public void destroy() {
		service = null;
	}

	
	@Test
	public void addReview() {
		Product product = new Product();
		product.setBrand("Nike");
	}
}
